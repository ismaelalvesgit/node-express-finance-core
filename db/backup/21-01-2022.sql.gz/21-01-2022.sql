/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: broker
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `broker` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `createdAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `broker_name_unique` (`name`)
) ENGINE = InnoDB AUTO_INCREMENT = 48 DEFAULT CHARSET = utf8;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: category
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `createdAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name_unique` (`name`)
) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: dividends
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `dividends` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `investmentId` bigint(20) unsigned NOT NULL,
  `status` enum('PROVISIONED', 'PAID') NOT NULL DEFAULT 'PROVISIONED',
  `type` enum('DIVIDEND', 'JCP', 'YIELD') NOT NULL,
  `dueDate` date NOT NULL,
  `qnt` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  `total` bigint(20) NOT NULL,
  `createdAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `dividends_investmentid_foreign` (`investmentId`),
  CONSTRAINT `dividends_investmentid_foreign` FOREIGN KEY (`investmentId`) REFERENCES `investment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: investment
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `investment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `categoryId` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `longName` varchar(255) DEFAULT NULL,
  `sector` varchar(255) NOT NULL DEFAULT 'ChangeMe',
  `balance` bigint(20) NOT NULL DEFAULT '0',
  `priceDay` bigint(20) DEFAULT NULL,
  `priceDayHigh` bigint(20) DEFAULT NULL,
  `priceDayLow` bigint(20) DEFAULT NULL,
  `changePercentDay` decimal(8, 2) DEFAULT NULL,
  `volumeDay` bigint(20) DEFAULT NULL,
  `previousClosePrice` bigint(20) DEFAULT NULL,
  `createdAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `investment_name_unique` (`name`),
  KEY `investment_categoryid_foreign` (`categoryId`),
  CONSTRAINT `investment_categoryid_foreign` FOREIGN KEY (`categoryId`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 16 DEFAULT CHARSET = utf8;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: migrations
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `batch` int(11) DEFAULT NULL,
  `migration_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: migrations_lock
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `migrations_lock` (
  `index` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `is_locked` int(11) DEFAULT NULL,
  PRIMARY KEY (`index`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: transaction
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `transaction` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `brokerId` bigint(20) unsigned NOT NULL,
  `investmentId` bigint(20) unsigned NOT NULL,
  `type` enum('BUY', 'SELL', 'RENT') NOT NULL,
  `negotiationDate` date NOT NULL,
  `dueDate` date DEFAULT NULL,
  `qnt` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  `total` bigint(20) NOT NULL,
  `createdAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `transaction_brokerid_foreign` (`brokerId`),
  KEY `transaction_investmentid_foreign` (`investmentId`),
  CONSTRAINT `transaction_brokerid_foreign` FOREIGN KEY (`brokerId`) REFERENCES `broker` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `transaction_investmentid_foreign` FOREIGN KEY (`investmentId`) REFERENCES `investment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 8 DEFAULT CHARSET = utf8;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: broker
# ------------------------------------------------------------

INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    1,
    'AGORA CTVM S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    2,
    'ATIVA INVESTIMENTOS S.A. CTCV',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    3,
    'BANCO ABN AMRO S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    4,
    'BANRISUL S/A CVMC',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    5,
    'BB BANCO DE INVESTIMENTO S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    6,
    'BGC LIQUIDEZ DTVM',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    7,
    'BRADESCO S/A CTVM',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    8,
    'BTG PACTUAL CTVM S.A.',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    9,
    'C6 CTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    10,
    'CITIGROUP GMB CCTVM S.A.',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    11,
    'CLEAR CORRETORA - GRUPO XP',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    12,
    'CM CAPITAL MARKETS CCTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    13,
    'CREDIT SUISSE BRASIL S.A. CTVM',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    14,
    'ELITE CCVM LTDA.',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    15,
    'FATOR S.A. CV',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    16,
    'GENIAL INSTITUCIONAL CCTVM S.A.',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    17,
    'GENIAL INVESTIMENTOS CVM S.A.',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    18,
    'GOLDMAN SACHS DO BRASIL CTVM',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    19,
    'GUIDE INVESTIMENTOS S.A. CV',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    20,
    'H.COMMCOR DTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    21,
    'ICAP DO BRASIL CTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    22,
    'IDEAL CTVM SA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    23,
    'ITAU CV S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    24,
    'J. P. MORGAN CCVM S.A.',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    25,
    'J. SAFRA CVC LTDA.',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    26,
    'MERC. DO BRASIL COR. S.A. CTVM',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    27,
    'MERRILL LYNCH S/A CTVM',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    28,
    'MIRAE ASSET WEALTH MANAGEMENT (BRASIL) CCTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    29,
    'MODAL DTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    30,
    'MORGAN STANLEY CTVM S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    31,
    'NECTON INVESTIMENTOS S.A. CVMC',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    32,
    'NOVA FUTURA CTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    33,
    'NU INVEST CORRETORA DE VALORES S.A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    34,
    'ÓRAMA DTVM S.A.',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    35,
    'PLANNER CV S.A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    36,
    'RB CAPITAL DTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    37,
    'RENASCENÇA DTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    38,
    'SANTANDER CCVM S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    39,
    'SINGULARE CTVM S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    40,
    'STONEX DISTRIBUIDORA DE TITULOS E VALORES MOBILIARIOS LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    41,
    'TERRA INVESTIMENTOS DTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    42,
    'TORO CVTM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    43,
    'TULLETT PREBON BRASIL CVC LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    44,
    'UBS BRASIL CCTVM S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    45,
    'VOTORANTIM CTVM LTDA',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    46,
    'XP INVESTIMENTOS CCTVM S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );
INSERT INTO
  `broker` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    47,
    'RICO INVESTIMENTOS CCTVM S/A',
    '2022-01-19 23:02:47.097',
    '2022-01-19 23:02:47.097'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: category
# ------------------------------------------------------------

INSERT INTO
  `category` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    1,
    'FUNDOS IMOBILIÁRIOS',
    '2022-01-19 23:02:47.095',
    '2022-01-19 23:02:47.095'
  );
INSERT INTO
  `category` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    2,
    'AÇÕES',
    '2022-01-19 23:02:47.095',
    '2022-01-19 23:02:47.095'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: dividends
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: investment
# ------------------------------------------------------------

INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    1,
    'VINO11',
    'Vinci Corporate Fundo De Investimento Imobiliario',
    'ChangeMe',
    16314,
    5368,
    5409,
    5330,
    -0.76,
    9481200,
    5330,
    '2022-01-19 23:57:39.714',
    '2022-01-21 21:00:00.346'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    2,
    1,
    'VISC11',
    'Vinci Shopping Centers Fundo Investimento Imobiliario - Fii',
    'SHOPPING',
    0,
    10175,
    10239,
    10100,
    -0.23,
    2328200,
    10100,
    '2022-01-21 00:11:48.834',
    '2022-01-21 20:50:00.345'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    3,
    1,
    'DEVA11',
    'Devant Recebiveis Imobiliarios Fundo De Investimento Imobiliario',
    ' PAPEL',
    0,
    10290,
    10314,
    10250,
    0.24,
    5733500,
    10250,
    '2022-01-21 17:03:07.232',
    '2022-01-21 21:00:00.343'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    4,
    1,
    'CPTS11',
    'Capitania Securities II Fundo Investimento Imobiliario FII',
    ' PAPEL',
    0,
    9716,
    9744,
    9687,
    0.25,
    9794200,
    9687,
    '2022-01-21 17:03:34.885',
    '2022-01-21 21:00:00.360'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    5,
    1,
    'MXRF11',
    'Maxi Renda Fundo De Investimento Imobiliaro - FII',
    ' PAPEL',
    0,
    1006,
    1006,
    1001,
    0.50,
    73485800,
    1001,
    '2022-01-21 17:03:42.330',
    '2022-01-21 20:50:00.372'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    6,
    1,
    'HGRU11',
    'CSHG Renda Urbana Fundo Investimento Imobilirio - FII',
    'HIBRIDO',
    0,
    11519,
    11630,
    11400,
    0.92,
    3536800,
    11400,
    '2022-01-21 17:04:08.836',
    '2022-01-21 20:45:00.360'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    7,
    1,
    'VGHF11',
    'Valora Hedge Fund Fundo De Investimento Imobiliario - Fii',
    'HIBRIDO',
    0,
    1040,
    1045,
    1025,
    0.78,
    16293100,
    1025,
    '2022-01-21 17:04:19.658',
    '2022-01-21 21:00:00.370'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    8,
    1,
    'XPLG11',
    'Xp Log Fundo Investimento Imobiliario FII',
    'GALPÃO',
    0,
    10139,
    10179,
    10026,
    1.29,
    3568700,
    10026,
    '2022-01-21 17:04:42.684',
    '2022-01-21 20:50:00.369'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    9,
    1,
    'BTLG11',
    'BTG Pactual Logística Fundo de Investimento Imobiliário',
    'GALPÃO',
    0,
    10580,
    10595,
    10525,
    0.09,
    3808500,
    10525,
    '2022-01-21 17:04:58.976',
    '2022-01-21 21:00:00.382'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    10,
    1,
    'HGLG11',
    'Cshg Logistica - Fundo De Investimento Imobiliario',
    'GALPÃO',
    0,
    17378,
    17464,
    17321,
    0.04,
    2321600,
    17321,
    '2022-01-21 17:05:04.925',
    '2022-01-21 21:00:00.367'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    11,
    1,
    'RZTR11',
    'Fundo De Investimento Imobiliario Riza Terrax',
    'AGRO',
    0,
    10282,
    10448,
    10180,
    0.74,
    4887400,
    10180,
    '2022-01-21 17:05:23.988',
    '2022-01-21 20:55:00.441'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    12,
    1,
    'HFOF11',
    'Hedge Top Fofii 3 Fundo Investimento Imobilirio',
    'FOF',
    0,
    8030,
    8070,
    8021,
    -0.50,
    1254400,
    8021,
    '2022-01-21 17:07:00.565',
    '2022-01-21 20:55:00.454'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    13,
    2,
    'BBAS3',
    'Banco do Brasil S.A.',
    'BANCO',
    0,
    3119,
    3154,
    3089,
    -0.03,
    1212310000,
    3089,
    '2022-01-21 17:09:47.554',
    '2022-01-21 20:55:00.441'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    14,
    2,
    'CSMG3',
    'Companhia de Saneamento de Minas Gerais',
    'INFRAESTRUTURA',
    0,
    1215,
    1239,
    1214,
    -1.78,
    134700000,
    1214,
    '2022-01-21 17:10:20.756',
    '2022-01-21 20:50:00.395'
  );
INSERT INTO
  `investment` (
    `id`,
    `categoryId`,
    `name`,
    `longName`,
    `sector`,
    `balance`,
    `priceDay`,
    `priceDayHigh`,
    `priceDayLow`,
    `changePercentDay`,
    `volumeDay`,
    `previousClosePrice`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    15,
    2,
    'MGLU3',
    'Magazine Luiza S.A.',
    'VAREJO',
    0,
    688,
    708,
    646,
    3.46,
    13907960000,
    646,
    '2022-01-21 17:10:42.229',
    '2022-01-21 20:50:00.402'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: migrations
# ------------------------------------------------------------

INSERT INTO
  `migrations` (`id`, `name`, `batch`, `migration_time`)
VALUES
  (
    1,
    '20210325220227_initSchema.js',
    1,
    '2022-01-19 20:02:44'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: migrations_lock
# ------------------------------------------------------------

INSERT INTO
  `migrations_lock` (`index`, `is_locked`)
VALUES
  (1, 0);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: transaction
# ------------------------------------------------------------

INSERT INTO
  `transaction` (
    `id`,
    `brokerId`,
    `investmentId`,
    `type`,
    `negotiationDate`,
    `dueDate`,
    `qnt`,
    `price`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    47,
    1,
    'BUY',
    '2021-12-10',
    NULL,
    1,
    5438,
    5438,
    '2022-01-19 23:57:39.727',
    '2022-01-19 23:57:39.727'
  );
INSERT INTO
  `transaction` (
    `id`,
    `brokerId`,
    `investmentId`,
    `type`,
    `negotiationDate`,
    `dueDate`,
    `qnt`,
    `price`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    2,
    47,
    1,
    'BUY',
    '2021-12-10',
    NULL,
    1,
    5438,
    5438,
    '2022-01-19 23:59:34.095',
    '2022-01-19 23:59:34.095'
  );
INSERT INTO
  `transaction` (
    `id`,
    `brokerId`,
    `investmentId`,
    `type`,
    `negotiationDate`,
    `dueDate`,
    `qnt`,
    `price`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    3,
    47,
    1,
    'BUY',
    '2021-12-10',
    NULL,
    1,
    5438,
    5438,
    '2022-01-20 00:02:04.646',
    '2022-01-20 00:02:04.646'
  );
INSERT INTO
  `transaction` (
    `id`,
    `brokerId`,
    `investmentId`,
    `type`,
    `negotiationDate`,
    `dueDate`,
    `qnt`,
    `price`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    4,
    47,
    1,
    'BUY',
    '2021-12-10',
    NULL,
    1,
    5438,
    5438,
    '2022-01-20 00:33:21.228',
    '2022-01-20 00:33:21.228'
  );
INSERT INTO
  `transaction` (
    `id`,
    `brokerId`,
    `investmentId`,
    `type`,
    `negotiationDate`,
    `dueDate`,
    `qnt`,
    `price`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    5,
    47,
    1,
    'SELL',
    '2021-12-10',
    NULL,
    1,
    5438,
    5438,
    '2022-01-20 00:33:55.578',
    '2022-01-20 00:33:55.578'
  );
INSERT INTO
  `transaction` (
    `id`,
    `brokerId`,
    `investmentId`,
    `type`,
    `negotiationDate`,
    `dueDate`,
    `qnt`,
    `price`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    6,
    47,
    1,
    'BUY',
    '2021-12-10',
    NULL,
    1,
    5438,
    5438,
    '2022-01-20 01:03:16.897',
    '2022-01-20 01:03:16.897'
  );
INSERT INTO
  `transaction` (
    `id`,
    `brokerId`,
    `investmentId`,
    `type`,
    `negotiationDate`,
    `dueDate`,
    `qnt`,
    `price`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    7,
    47,
    1,
    'BUY',
    '2021-12-10',
    NULL,
    1,
    5438,
    5438,
    '2022-01-20 01:03:18.473',
    '2022-01-20 01:03:18.473'
  );

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
